Read Me File
This application was ran using the CIS2701-2024-Development-Environment container using Docker Desktop. The code itself was developed using Microsoft VS Code. 
The Dev Extension container was used to help connect Microsoft VS Code to the Docker Desktop Application. 

To run this Vending Machine application the Readline module to accept the user input needs to be downloaded. To download this module the code npm install readline is needed to install the readline module.

This application runs using Vanilla JavaScript and the terminal to run the code. 
To start the application you must type into the terminal node Madoc-Jones_G_
25646648_CW2_Code. 

If you exit the code using the provided exit feature retype the above name to restart the application. 

Commented through the application are detailed comments that help to explain the overall functionality of the code, what certain code elements do and lastly the relevant resources used to help develop the code.